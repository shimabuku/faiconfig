#ifndef __A_OUT_GNU_H__
# error "Never use <bits/a.out.h> directly; include <a.out.h> instead."
#endif
